package com.example.sesiones._5_6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sesiones456Application {

	public static void main(String[] args) {
		SpringApplication.run(Sesiones456Application.class, args);
	}

}
