package com.example.sesiones._5_6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sesiones456ApplicationTests {

	@Test
	void contextLoads() {
	}

}
